import time
starttime=time.time()
L=input('ENTER SIZE OF SQUARE:')
l=float(L)
area=l*l
print("AREA OF THE SQUARE IS(SQUARE UNITS):",float(area))
p=4*l
print("PERIMETER OF THE SQUARE IS(UNITS):",float(p))
endtime=time.time()
tt=(endtime-starttime)
print('TOTAL TIME OF EXECUTION:',tt)

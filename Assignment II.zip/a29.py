import time
starttime=time.time()
n=input('Enter the number of values')
n=int(n)
i=1
sum=0
while(i<=n):
    sum=sum+i
    i=i+1
print('Total sum:',sum)
endtime=time.time()
tt=(endtime-starttime)
print("Total time for execution: ",tt)
